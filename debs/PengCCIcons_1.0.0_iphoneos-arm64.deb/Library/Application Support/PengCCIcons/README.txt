本目录用于存放从相册导出的图标/视频/GIF 素材（运行时由插件写入）。
deb 由 Linux 沙箱手工组装，二进制为占位；真正的 PengCCIcons.dylib /
PengCCIconsPrefs 需在 macOS 用 Theos 编译后替换并重新打包。
